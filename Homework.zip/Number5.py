## Задание 5

profit = input("Введите прибыль фирмы")
profit = int(profit)
loss = input("Введите расходы фирмы")
loss = int(loss)
fin_result = profit - loss 

if fin_result > 0 :
    print("У нас прибыль больше расходов. Так держать!")
    rentability = fin_result/ profit
else:
    print("Грустно.. Мы работаем, а где же деньги ??")

employee = input("Введите количество сотрудников")
employee = int(employee)
profit_per_employee = fin_result / employee 

print(profit_per_employee, "Рублей прибыли на сотрудника")